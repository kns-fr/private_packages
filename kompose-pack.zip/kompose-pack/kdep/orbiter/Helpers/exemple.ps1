
function helperExample() {
	return "From helper";
}
