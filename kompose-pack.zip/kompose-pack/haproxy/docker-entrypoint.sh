#!/bin/bash
cp -f /usr/local/etc/haproxy/haproxy_template.cfg /tmp/haproxy.cfg 


echo $ACTIVE_PROFILE

## activation des composants
IFS=',' read -ra elements <<< "$ACTIVE_PROFILE"
for element in "${elements[@]}"; do
    echo "ENABLE ${element^^}"
    # On remplace #VALEUR par rien dans le fichier
    sed -i "s/#${element^^}//g" /tmp/haproxy.cfg 
done


sed -i "s/KDIR_HOSTNAME/${KDIR_HOSTNAME}/g" /tmp/haproxy.cfg 
sed -i "s|KDIR_PATH|${KDIR_PATH}|g" /tmp/haproxy.cfg 


sed -i "s/KDEP_HOSTNAME/${KDEP_HOSTNAME}/g" /tmp/haproxy.cfg 
sed -i "s|KDEP_PATH|${KDEP_PATH}|g" /tmp/haproxy.cfg 

sed -i "s/KC_HOSTNAME_ADMIN/${KC_HOSTNAME_ADMIN}/g" /tmp/haproxy.cfg 
sed -i "s/KC_HOSTNAME/${KC_HOSTNAME}/g" /tmp/haproxy.cfg 
sed -i "s|KC_PATH|${KC_PATH}|g" /tmp/haproxy.cfg 


sed -i "s/KBATCH_HOSTNAME/${KBATCH_HOSTNAME}/g" /tmp/haproxy.cfg 
sed -i "s|KBATCH_PATH|${KBATCH_PATH}|g" /tmp/haproxy.cfg 

sed -i "s/DEFAUT_BACKEND/${DEFAUT_BACKEND}/g" /tmp/haproxy.cfg 

cat /tmp/haproxy.cfg 

/usr/local/bin/docker-entrypoint.sh haproxy -f "/tmp/haproxy.cfg"