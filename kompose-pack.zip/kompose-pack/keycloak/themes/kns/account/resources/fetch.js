/**
 * Avoid fetch to send 'content-type' header if it's a "GET" request.
 * If 'content-type' header exists, remove header set value in 'accept' header
 */
const originalFetch = window.fetch;

window.fetch = (resource, config) => {
    if (config?.method?.toLowerCase() === 'get' && config?.headers) {
        const headerNames = Object.keys(config.headers);
        for (const header of headerNames) {
            if (header.toLowerCase() === 'content-type') {
                config.headers.accept = config.headers[header];
                delete config.headers[header];
            }
        }
    }
    return originalFetch(resource, config);
}