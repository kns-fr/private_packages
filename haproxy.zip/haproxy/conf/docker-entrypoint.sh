#!/bin/sh
cp -f /usr/local/etc/haproxy/haproxy_template.cfg /tmp/haproxy.cfg 

sed -i "s/HA_HOSTNAME_ADMIN/${HA_HOSTNAME_ADMIN}/g" /tmp/haproxy.cfg 
sed -i "s/HA_HOSTNAME/${HA_HOSTNAME}/g" /tmp/haproxy.cfg 

sed -i "s/HA_BACKEND_1/${HA_BACKEND_1}/g" /tmp/haproxy.cfg 
sed -i "s/HA_BACKEND_2/${HA_BACKEND_2}/g" /tmp/haproxy.cfg 

sed -i "s/HA_ROOT_REDIRECT/${HA_ROOT_REDIRECT}/g" /tmp/haproxy.cfg 



/usr/local/bin/docker-entrypoint.sh haproxy -f "/tmp/haproxy.cfg"