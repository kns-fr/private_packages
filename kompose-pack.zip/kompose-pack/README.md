# Deploiment par docker-compose
1. mettre à jour le fichier .env
3. Lancer le docker compose
```shell
docker-compose pull
docker-compose up --force-recreate -d
```


# Matomo
module : https://github.com/EmmanuelRoux/ngx-matomo-client
admin / changeMe