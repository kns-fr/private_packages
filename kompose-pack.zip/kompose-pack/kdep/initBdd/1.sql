SET @@global.sql_mode= '';

create table knsobject
(
    id              bigint,
    externalId      varchar(512) null,
    type            varchar(512) null,
    kNSAttributesAA json         null,
    kNSAttributes   json         null
);

create index knsobject_externalId_index
    on knsobject (externalId);

create index knsobject_id_index
    on knsobject (id);

create index knsobject_type_index
    on knsobject (type);

alter table knsobject
    add constraint knsobject_pk
        primary key (id);

alter table knsobject
    modify id bigint auto_increment;

create table knsobject_relation
(
    id                       bigint,
    name                     varchar(128) not null,
    knsobject_id_origin      bigint       not null,
    knsobject_id_destination bigint       not null
);

alter table knsobject
    add whenCreated datetime default CURRENT_TIMESTAMP not null;

alter table knsobject
    add whenChanged datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP;

alter table knsobject_relation
    add whenCreated datetime default CURRENT_TIMESTAMP not null;

alter table knsobject_relation
    add whenChanged datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP;



create index knsobject_relation_id_index
    on knsobject_relation (id);

create index knsobject_relation_knsobject_id_destination_index
    on knsobject_relation (knsobject_id_destination);

create index knsobject_relation_knsobject_id_origin_index
    on knsobject_relation (knsobject_id_origin);

create index knsobject_relation_name_index
    on knsobject_relation (name);

alter table knsobject_relation
    add constraint knsobject_relation_pk
        primary key (id);

alter table knsobject_relation
    modify id bigint auto_increment;

alter table knsobject_relation
    add constraint knsobject_relation_knsobject_id_fk
        foreign key (knsobject_id_origin) references knsobject (id);

alter table knsobject_relation
    add constraint knsobject_relation_knsobject_id_fk_2
        foreign key (knsobject_id_destination) references knsobject (id);