# PowerShell example 2 by Gabriel Genois <gabriel.genois@kns.fr> 06/05/2022
# © 2022 KNS, All rights reserved

#	Toute les fonctions doivent retourer un objet JSON avec au minimum
#	un code et un message.
#	- Les codes négatifs sont considérés comme des erreurs bloquantes.
#	- Le code 0 est un succès.
#	- Les codes positifs sont des averstissements non-bloquants.
#
#	Les codes d'erreurs on des plages réservés
#	- -1			Erreur 
#	- -2 à -99 		Erreurs automatiques au niveau structurels (Côté TPL)
#	- -100 à -999	Erreurs standards (Côté Scripts transverse)
#	- -1000 et -		Erreurs propres aux scripts et à chaque fonctions (
#
#	Par exemple:
#	-1		Exeption générale avec nom de la fonction et le message d'erreur.
#	-101	Erreur de connexion
#	-102	Erreur de permission
#	-1000	Erreur de recalcul de kad.	

param (
	[parameter(Mandatory=$false)]
	[switch]$Discover   = $false,
	
	[parameter(Mandatory=$false)]
	[string]$Function   = "",
	
	[parameter(Mandatory=$false)]
	[string]$InputData  = "",

	
	[parameter(Mandatory=$false)]
	[string]$Identity  = ""
	)
    
# Meta
# ###################################
# Déclare l'ensemble des fonctions "appelables" dans le script avec leur
# paramètres attentus. Attention; Il s'agit des paramètre **MINIMUM** attendu;
# on n'empêche pas l'ajout d'autres champs dans l'envoie. Mais ceux-ci ne
# seront pas controlés ou vérifiés.
#
# Permet, par exemple, les appels suivants:
# - pwsh ./exemple_2_tpl.ps
# - pwsh ./exemple_2_tpl.ps -function delete-user -discover true
#
# Le schéma ce déclare comme suit:
#
# "Nom de la fonction"		tableau	Contient les MétaDonnées du script
#	Name					string	Nom visible dans le fronend TPL
#	Description				string	Description visible dans le frontend TPL
#	CreationDate			string	Usage interne: Date de création du script
#	ModificationDate		string	Usage interne: Date de derniere modification du script.
#	AuthorName				string	Usage interne: Qui à créer le script
#	AuthorEmail				string	Usage interne: Email de qui a créer le script.
#	schema					tableau contenant le schéma accepté par la function
#		"Nom de l'élément"	tableau	Contient le schéma de l'élément. Nom unique libre.
#			attr			string	Représente le nom technique de l'attribut
#			name			string	Nom visible dans le frontend TPL
#			type			string	Déclare le type attentu. Voir plus bas pour les types disponnibles
#			mandatory		boolean	Si le champs est obligatoire ou non.
#
#
# Les TYPEs supportés pour les éléments du schéma:
#
#	Les Types "de bases" supportés.
#	======================================
#	string		Chaine de caractère
#	number		Nombre Entier signé 64bit (-9,223,372,036,854,775,808 à 9,223,372,036,854,775,807),
#	boolean		Boolean (true/false)
#
#	Les types complexes utilisant les types de bases:
#	======================================
#	array<TYPE>			Tableau simple
#	list<TYPE, TYPE>	Tableau de type "liste" ou "dictionaire" au format "clefs => valeur ".
#	
#	

$name=$env:KAPP_NAME
# Les Meta
$Meta = 
    @{
        "descriptor" = @{
            "Name"			= "${name}";
            "Description"	= "Gestion de la base de donnée (alimentation) "
            "UID" 			= "${name}BDDUser"
            "Group"             = "Kapps";
            "Color"             = "#FAA";
            "Icon"              = "verified";
        };
	    "add-user" = @{
		    "Name"				= "Ajout d'utilisateurs";
		    "Description"		= "Ajouter un utilisateur"
     		"CreationDate"		= "18/02/2025"
     		"ModificationDate"	= "18/02/2025"
		    "AuthorName"		= "CLAUDEL Mathieu";
     		"AuthorEmail"		= "mathieu.claudel@kns.fr";
		    "schema"			= @{
			    "cn"	= @{
				    "Attr" = "cn";
				    "Name" = "cn";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"description" = @{
				    "Attr" = "description";
				    "Name" = "active";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };				
				"kNSString01" = @{
				    "Attr" = "kNSString01";
				    "Name" = "civilite";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"kNSString20" = @{
				    "Attr" = "kNSString20";
				    "Name" = "nom";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"givenName" = @{
				    "Attr" = "givenName";
				    "Name" = "prenom";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"middleName" = @{
				    "Attr" = "middleName";
				    "Name" = "nom_naissance";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"kNSString02" = @{
				    "Attr" = "kNSString02";
				    "Name" = "username";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"employeeNumber" = @{
				    "Attr" = "employeeNumber";
				    "Name" = "rpps";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };				
				"mail" = @{
				    "Attr" = "mail";
				    "Name" = "mail";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };		
				"title" = @{
				    "Attr" = "title";
				    "Name" = "civilite";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };	
				"kNSString04" = @{
				    "Attr" = "kNSString04";
				    "Name" = "rpps_plus";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"kNSString05" = @{
				    "Attr" = "kNSString05";
				    "Name" = "rpps_plus_valide";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"kNSString11" = @{
				    "Attr" = "kNSString11";
				    "Name" = "metier_ordre";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"kNSString12" = @{
				    "Attr" = "kNSString12";
				    "Name" = "metier_role";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };				
				"kNSString13" = @{
				    "Attr" = "kNSString13";
				    "Name" = "metier";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"kNSString31" = @{
				    "Attr" = "kNSString31";
				    "Name" = "source";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"kNSString40" = @{
				    "Attr" = "kNSString40";
				    "Name" = "email_perso";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };	
				"kNSString41" = @{
				    "Attr" = "kNSString41";
				    "Name" = "tel_perso";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };	
				"kNSString49" = @{
				    "Attr" = "kNSString49";
				    "Name" = "charte";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };		
				"uf" = @{
				    "Attr" = "uf";
				    "Name" = "uf";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"service" = @{
				    "Attr" = "service";
				    "Name" = "service";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"pole" = @{
				    "Attr" = "pole";
				    "Name" = "pole";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"etablissement" = @{
				    "Attr" = "etablissement";
				    "Name" = "etablissement";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };																																																														
			    # Ajouter ici les attribut manquants pour le test.
		    };
		};
		"add-org" = @{
		    "Name"				= "Ajout d'organisations";
		    "Description"		= "Ajouter des organisations"
     		"CreationDate"		= "18/02/2025"
     		"ModificationDate"	= "18/02/2025"
		    "AuthorName"		= "CLAUDEL Mathieu";
     		"AuthorEmail"		= "mathieu.claudel@kns.fr";
		    "schema"			= @{
			    "cn"	= @{
				    "Attr" = "cn";
				    "Name" = "cn";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"displayName" = @{
				    "Attr" = "displayName";
				    "Name" = "displayName";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };				
				"kNSString55" = @{
				    "Attr" = "source";
				    "Name" = "source";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"kNSString02" = @{
				    "Attr" = "type";
				    "Name" = "type";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };				
				"parent" = @{
				    "Attr" = "parent";
				    "Name" = "parent";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };		
				"etablissement" = @{
				    "Attr" = "etablissement";
				    "Name" = "etablissement";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };		
			    # Ajouter ici les attribut manquants pour le test.
		    };			
	    };
		"add-role" = @{
		    "Name"				= "Ajout d'un role a utilisateur";
		    "Description"		= "Ajout d'un role a utilisateur"
     		"CreationDate"		= "18/02/2025"
     		"ModificationDate"	= "18/02/2025"
		    "AuthorName"		= "CLAUDEL Mathieu";
     		"AuthorEmail"		= "mathieu.claudel@kns.fr";
		    "schema"			= @{
			    "cn"	= @{
				    "Attr" = "cn";
				    "Name" = "cn";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"roles" = @{
				    "Attr" = "role";
				    "Name" = "role";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };																			
			    # Ajouter ici les attribut manquants pour le test.
		    };
		};	
		"add-card" = @{
		    "Name"				= "Ajout de cartes";
		    "Description"		= "Ajout de carte à un utilisateurs"
     		"CreationDate"		= "18/02/2025"
     		"ModificationDate"	= "18/02/2025"
		    "AuthorName"		= "CLAUDEL Mathieu";
     		"AuthorEmail"		= "mathieu.claudel@kns.fr";
		    "schema"			= @{
			    "cn"	= @{
				    "Attr" = "cn";
				    "Name" = "cn";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"numero_carte" = @{
				    "Attr" = "numero_carte";
				    "Name" = "numero_carte";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"type" = @{
				    "Attr" = "type";
				    "Name" = "type";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"active" = @{
				    "Attr" = "active";
				    "Name" = "active";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"stade" = @{
				    "Attr" = "stade";
				    "Name" = "stade";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"puk" = @{
				    "Attr" = "puk";
				    "Name" = "puk";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"rpps" = @{
				    "Attr" = "rpps";
				    "Name" = "rpps";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"enrolement" = @{
				    "Attr" = "enrolement";
				    "Name" = "enrolement";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"distribution" = @{
				    "Attr" = "distribution";
				    "Name" = "distribution";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"source" = @{
				    "Attr" = "source";
				    "Name" = "source";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"kNSString56" = @{
				    "Attr" = "kNSString56";
				    "Name" = "kNSString56";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };
				"users" = @{
				    "Attr" = "users";
				    "Name" = "users";
				    "Type" = "string";
				    "Mandatory" = $true;
			    };																																																																												
			    # Ajouter ici les attribut manquants pour le test.
		};						
	};
};


# add-user
# ======================================
function add-user($data) {
    try {
        $code = 0;

		# on ajoute l'identitée pour la visualisation
		# $Identity = $Identity | ConvertFrom-Json -AsHashTable

        # erreur de code
        if (-not $data["cn"]){
	        return @{
	            "code" = -1001;
	            "message" = "Pas de external id";
            } | ConvertTo-Json
        } else {
            # code normal de retour du test
            $id = $data.cn
        }
		#$jsonAttr = $data | ConvertTo-Json

		$jsonAttr = @{
			          "cn"=$data.cn
		              "middleName"=$data.nom_naissance
					  "givenName"=$data.prenom  
					  "description"=$data.active
					  "title"=$data.titre
					  "employeeNumber"=$data.rpps
					  "mail"=$data.mail
					  "kNSString01"=$data.civilite
					  "kNSString02"=$data.username
					  "kNSString04"=$data.rpps_plus
					  "kNSString05"=$data.rpps_plus_valide
					  "kNSString11"=$data.metier_ordre
					  "kNSString12"=$data.metier_role
					  "kNSString13"=$data.metier
					  "kNSString20"=$data.nom
					  "kNSString31"=$data.source
					  "kNSString40"=$data.email_perso
					  "kNSString41"=$data.tel_perso
					  "kNSString49"=$data.charte
		}  | ConvertTo-Json -Compress
		

		# utilisation de https://github.com/mithrandyr/SimplySql
		$user = "kdep"
		$pwd = ConvertTo-SecureString "KsocleP@ssw0rdK@EnEs69" -AsPlainText -Force
		$cred = New-Object System.Management.Automation.PSCredential($user,$pwd)

		# https://github.com/mithrandyr/SimplySql/blob/master/Docs/Open-MySqlConnection.md
		Open-MySQLConnection -Server "mariadb" -Verbose -Port 3306 -Database "kbase" -Credential $cred
		$sql = "insert into knsobject (externalId, type, kNSAttributes) VALUES ('CN="+$id+",OU=USERS,DC=KDEP', 'USERS', '"+$jsonAttr+"') ON DUPLICATE KEY UPDATE kNSAttributes='"+$jsonAttr+"'"
	    $msg = Invoke-SqlQuery -Query ($sql)


		if ($data.etablissement -ne "") {
			$sql = "delete from knsobject_relation where knsobject_id_origin = (SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=USERS,DC=KDEP') and name='kNSMVRef01'";
			$msg = Invoke-SqlQuery -Query ($sql)
			$items = $data.etablissement -split ","
			foreach($item in $items) {
				$sql = "insert into knsobject_relation (name, knsobject_id_origin, knsobject_id_destination) VALUE ('kNSMVRef01',(SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=USERS,DC=KDEP'), (SELECT id FROM knsobject WHERE externalId = 'CN="+$item+",OU=ORGANISATION,DC=KDEP'))";
				$msg = Invoke-SqlQuery -Query ($sql)
			}
		}
		if ($data.pole -ne "") {
			$sql = "delete from knsobject_relation where knsobject_id_origin = (SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=USERS,DC=KDEP') and name='kNSMVRef04'";
			$msg = Invoke-SqlQuery -Query ($sql)
			$items = $data.pole -split ","
			foreach($item in $items) {
				$sql = "insert into knsobject_relation (name, knsobject_id_origin, knsobject_id_destination) VALUE ('kNSMVRef04',(SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=USERS,DC=KDEP'), (SELECT id FROM knsobject WHERE externalId = 'CN="+($item)+",OU=ORGANISATION,DC=KDEP'))";
				$msg = Invoke-SqlQuery -Query ($sql)
			}
		}
		if ($data.service -ne "") {
			$sql = "delete from knsobject_relation where knsobject_id_origin = (SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=USERS,DC=KDEP') and name='kNSMVRef03'";
			$msg = Invoke-SqlQuery -Query ($sql)
			$items = $data.service -split ","
			foreach($item in $items) {
				$sql = "insert into knsobject_relation (name, knsobject_id_origin, knsobject_id_destination) VALUE ('kNSMVRef03',(SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=USERS,DC=KDEP'), (SELECT id FROM knsobject WHERE externalId = 'CN="+($item)+",OU=ORGANISATION,DC=KDEP'))";
				$msg = Invoke-SqlQuery -Query ($sql)
			}
		}		
		if ($data.uf -ne "") {
			$sql = "delete from knsobject_relation where knsobject_id_origin = (SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=USERS,DC=KDEP') and name='kNSMVRef02'";
			$msg = Invoke-SqlQuery -Query ($sql)
			$items = $data.uf -split ","
			foreach($item in $items) {
				$sql = "insert into knsobject_relation (name, knsobject_id_origin, knsobject_id_destination) VALUE ('kNSMVRef02',(SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=USERS,DC=KDEP'), (SELECT id FROM knsobject WHERE externalId = 'CN="+($item)+",OU=ORGANISATION,DC=KDEP'))";
				$msg = Invoke-SqlQuery -Query ($sql)
			}
		}	

        # retour ok
	    return @{
	        "code" = $code
	        "message" = $msg | ConvertTo-Json -Depth 3 -Compress;
            "audit"   = "Creation ok"
        } | ConvertTo-Json
    } catch {
        return @{
	        "code" = -1000
	        "message" = $_  | ConvertTo-Json -Depth 3 -Compress;
        }
    }
}



# add-user
# ======================================
function add-org($data) {
    try {
        $code = 0;

		# on ajoute l'identitée pour la visualisation
		# $Identity = $Identity | ConvertFrom-Json -AsHashTable

        # erreur de code
        if (-not $data["cn"]){
	        return @{
	            "code" = -1001;
	            "message" = "Pas de external id";
            } | ConvertTo-Json
        } else {
            # code normal de retour du test
            $id = $data.cn
        }
		#$jsonAttr = $data | ConvertTo-Json

		$jsonAttr = @{
			          "cn"=$data.cn
					  "displayName"=$data.displayName
					  "kNSString02"=$data.type					  
					  "kNSString55"=$data.source
		}  | ConvertTo-Json -Compress
		

		# utilisation de https://github.com/mithrandyr/SimplySql
		$user = "kdep"
		$pwd = ConvertTo-SecureString "KsocleP@ssw0rdK@EnEs69" -AsPlainText -Force
		$cred = New-Object System.Management.Automation.PSCredential($user,$pwd)

		# https://github.com/mithrandyr/SimplySql/blob/master/Docs/Open-MySqlConnection.md
		Open-MySQLConnection -Server "mariadb" -Verbose -Port 3306 -Database "kbase" -Credential $cred
		$sql = "insert into knsobject (externalId, type, kNSAttributes) VALUES ('CN="+$id+",OU=ORGANISATION,DC=KDEP', 'ORGANISATION', '"+$jsonAttr+"') ON DUPLICATE KEY UPDATE kNSAttributes='"+$jsonAttr+"'"
	    $msg = Invoke-SqlQuery -Query ($sql)


		if ($data.parent -ne "") {
			$sql = "delete from knsobject_relation where knsobject_id_origin = (SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=ORGANISATION,DC=KDEP') and name='member'";
			$msg = Invoke-SqlQuery -Query ($sql)			
			$sql = "insert into knsobject_relation (name, knsobject_id_origin, knsobject_id_destination) VALUE ('member',(SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=ORGANISATION,DC=KDEP'), (SELECT id FROM knsobject WHERE externalId = 'CN="+($data.parent)+",OU=ORGANISATION,DC=KDEP'))";
			$msg = Invoke-SqlQuery -Query ($sql)
		}
		
		if ($data.etablissement -ne "") {
			$sql = "delete from knsobject_relation where knsobject_id_origin = (SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=ORGANISATION,DC=KDEP') and name='kNSMVRef01'";
			$msg = Invoke-SqlQuery -Query ($sql)			
			$sql = "insert into knsobject_relation (name, knsobject_id_origin, knsobject_id_destination) VALUE ('kNSMVRef01',(SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=ORGANISATION,DC=KDEP'), (SELECT id FROM knsobject WHERE externalId = 'CN="+($data.etablissement)+",OU=ORGANISATION,DC=KDEP'))";
			$msg = Invoke-SqlQuery -Query ($sql)
		}
		

        # retour ok
	    return @{
	        "code" = $code
	        "message" = $msg | ConvertTo-Json -Depth 3 -Compress;
            "audit"   = "Creation ok"
        } | ConvertTo-Json
    } catch {
        return @{
	        "code" = -1000
	        "message" = $_  | ConvertTo-Json -Depth 3 -Compress;
        }
    }
}


# add-role
# ======================================
function add-role($data) {
    try {
        $code = 0;

		# on ajoute l'identitée pour la visualisation
		# $Identity = $Identity | ConvertFrom-Json -AsHashTable

        # erreur de code
        if (-not $data["cn"]){
	        return @{
	            "code" = -1001;
	            "message" = "Pas de external id";
            } | ConvertTo-Json
        } else {
            # code normal de retour du test
            $id = $data.cn
        }
		#$jsonAttr = $data | ConvertTo-Json


		# utilisation de https://github.com/mithrandyr/SimplySql
		$user = "kdep"
		$pwd = ConvertTo-SecureString "KsocleP@ssw0rdK@EnEs69" -AsPlainText -Force
		$cred = New-Object System.Management.Automation.PSCredential($user,$pwd)

		# https://github.com/mithrandyr/SimplySql/blob/master/Docs/Open-MySqlConnection.md
		Open-MySQLConnection -Server "mariadb" -Verbose -Port 3306 -Database "kbase" -Credential $cred

		$sql = "delete from knsobject_relation where knsobject_id_origin = (SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=USERS,DC=KDEP') and name='kNSMVRef02'";
		$msg = Invoke-SqlQuery -Query ($sql)			
		if ($data.role -ne "") {
		
			$sql = "insert into knsobject_relation (name, knsobject_id_origin, knsobject_id_destination) VALUE ('kNSMVRef01',(SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=USERS,DC=KDEP'), (SELECT id FROM knsobject WHERE externalId = 'CN="+($data.role)+",OU=ROLE,DC=KDEP'))";
			$msg = Invoke-SqlQuery -Query ($sql)
		}

        # retour ok
	    return @{
	        "code" = $code
	        "message" = $msg | ConvertTo-Json -Depth 3 -Compress;
            "audit"   = "Creation ok"
        } | ConvertTo-Json
    } catch {
        return @{
	        "code" = -1000
	        "message" = $_  | ConvertTo-Json -Depth 3 -Compress;
        }
    }
}



# add-card
# ======================================
function add-card($data) {
    try {
        $code = 0;

		# on ajoute l'identitée pour la visualisation
		# $Identity = $Identity | ConvertFrom-Json -AsHashTable

        # erreur de code
        if (-not $data["cn"]){
	        return @{
	            "code" = -1001;
	            "message" = "Pas de external id";
            } | ConvertTo-Json
        } else {
            # code normal de retour du test
            $id = $data.cn
        }
		#$jsonAttr = $data | ConvertTo-Json

		$type = 0
		switch ($data.type.ToLower()) {
			"cpe" {	$type = 1 }
			"cps" {	$type = 2 }
		}

		$jsonAttr = @{
			          "cn"=$data.cn
					  "kNSString01"=$data.numero_carte
					  "kNSString02"="$type"
					  "kNSString03"=$data.active
					  "kNSString04"=$data.stade
					  "kNSString06"=$data.puk
					  "kNSString07"=$data.rpps
					  "kNSString13"=$data.enrolement
					  "kNSString14"=$data.distribution
					  "kNSString31"=$data.source
					  "kNSString56"=$data.kNSString56
		}  | ConvertTo-Json -Compress
		

		# utilisation de https://github.com/mithrandyr/SimplySql
		$user = "kdep"
		$pwd = ConvertTo-SecureString "KsocleP@ssw0rdK@EnEs69" -AsPlainText -Force
		$cred = New-Object System.Management.Automation.PSCredential($user,$pwd)

		# https://github.com/mithrandyr/SimplySql/blob/master/Docs/Open-MySqlConnection.md
		Open-MySQLConnection -Server "mariadb" -Verbose -Port 3306 -Database "kbase" -Credential $cred
		$sql = "insert into knsobject (externalId, type, kNSAttributes) VALUES ('CN="+$id+",OU=CARTES,DC=KDEP', 'CARTES', '"+$jsonAttr+"') ON DUPLICATE KEY UPDATE kNSAttributes='"+$jsonAttr+"'"
	    $msg = Invoke-SqlQuery -Query ($sql)


		if ($data.users -ne "") {
			$sql = "delete from knsobject_relation where knsobject_id_origin = (SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=USERS,DC=KDEP') and name='kNSMVRef08'";
			$msg = Invoke-SqlQuery -Query ($sql)
			$items = $data.users -split ","
			foreach($item in $items) {
				$sql = "insert into knsobject_relation (name, knsobject_id_destination, knsobject_id_origin) VALUE ('kNSMVRef08',(SELECT id FROM knsobject WHERE externalId = 'CN="+$id+",OU=CARTES,DC=KDEP'), (SELECT id FROM knsobject WHERE externalId = 'CN="+($item)+",OU=USERS,DC=KDEP'))";
				$msg = Invoke-SqlQuery -Query ($sql)
			}
		}	

        # retour ok
	    return @{
	        "code" = $code
	        "message" = $msg | ConvertTo-Json -Depth 3 -Compress;
            "audit"   = "Creation ok"
        } | ConvertTo-Json
    } catch {
        return @{
	        "code" = -1000
	        "message" = $_  | ConvertTo-Json -Depth 3 -Compress;
        }
    }
}


# At the end of the file, we append helpers and directors functions.