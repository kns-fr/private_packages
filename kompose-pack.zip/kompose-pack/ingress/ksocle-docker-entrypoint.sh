#!/bin/bash
# vim:sw=4:ts=4:et
if [ -z "$KAPP_NAME" ]; then
	KAPP_NAME=KSOCLE
fi
echo [$KAPP_NAME WEBAPP] CHECK ENV


if [ "$IDP_BASE_URL" = "" ]; then
	echo IDP_BASE_URL must be set
	exit
fi
if [ "$API_URL" = "" ]; then
	echo API_URL must be set
	exit
fi


echo [$KAPP_NAME WEBAPP] update WEBAPP_BASE_HREF by ENV
sed -i 's|{WEBAPP_BASE_HREF}|'"$WEBAPP_BASE_HREF"'|g' /usr/share/nginx/html/*.html
sed -i 's|{WEBAPP_BASE_HREF}|'"$WEBAPP_BASE_HREF"'|g' /etc/nginx/conf.d/default.conf
sed -i 's|{KAPP_NAME}|'"$KAPP_NAME"'|g' /etc/nginx/conf.d/default.conf



echo [$KAPP_NAME WEBAPP] update configurations assets by ENV
sed -i 's|{IDP_BASE_URL}|'"$IDP_BASE_URL"'|g' /usr/share/nginx/html/assets/configurations/*.json
sed -i 's|{IDP_REALM}|'"$IDP_REALM"'|g' /usr/share/nginx/html/assets/configurations/*.json
sed -i 's|{WEBAPP_CLIENT_ID}|'"$WEBAPP_CLIENT_ID"'|g' /usr/share/nginx/html/assets/configurations/*.json
sed -i 's|{BASE_DN}|'"$LDAP_BASE_DN"'|g' /usr/share/nginx/html/assets/configurations/*.json
sed -i 's|{CGU_URL}|'"$CGU_URL"'|g' /usr/share/nginx/html/assets/configurations/*.json

REFERENCES_LIST="\"${REFERENCES_LIST//,/\",\"}\""
sed -i 's|{REFERENCES_LIST}|'"$REFERENCES_LIST"'|g' /usr/share/nginx/html/assets/configurations/*.json





sed -i 's|{API_URL}|'"$API_URL"'|g' /usr/share/nginx/html/assets/configurations/*.json

sed -i 's|<title>[^<]*</title>|'"<title>$WEBAPP_TITLE</title>"'|g' /usr/share/nginx/html/index.html

if [ "$ALLOW_BACKEND" = "" ]; then
    echo [$KAPP_NAME WEBAPP] DISABLE BACKEND
	sed -i 's|#ALLOW_BACKEND|#DISABLE_BACKEND|g' /etc/nginx/conf.d/default.conf
else
    echo [$KAPP_NAME WEBAPP] ALLOW BACKEND
	sed -i 's|#ALLOW_BACKEND||g' /etc/nginx/conf.d/default.conf
fi


if [[ " ,$ACTIVE_PROFILE, " =  *",kbatch,"* ]]; then
    echo [$KAPP_NAME WEBAPP] ALLOW KBATCH
	sed -i 's|#ALLOW_KBATCH||g' /etc/nginx/conf.d/default.conf
else
	echo [$KAPP_NAME WEBAPP] DISABLE KBATCH
	sed -i 's|#ALLOW_KBATCH|#DISABLE_KBATCH|g' /etc/nginx/conf.d/default.conf
fi


if [[ " ,$ACTIVE_PROFILE, " =  *",matomo,"* ]]; then
	echo [$KAPP_NAME WEBAPP] ALLOW MATOMO
	sed -i 's|#ALLOW_MATOMO||g' /etc/nginx/conf.d/default.conf
	echo [$KAPP_NAME WEBAPP] Configure MATOMO URL=$MATOMO_URL and ID=$MATOMO_ID
	sed -i 's|forRoot({trackerUrl:"[^"]*",siteId:"[^"]*"})|forRoot({trackerUrl:"{MATOMO_URL}",siteId:"{MATOMO_ID}"})|g' /usr/share/nginx/html/main*.js
	sed -i 's|{MATOMO_URL}|'"$MATOMO_URL"'|g' /usr/share/nginx/html/main*.js
	sed -i 's|{MATOMO_ID}|'"$MATOMO_ID"'|g' /usr/share/nginx/html/main*.js

else
	echo [$KAPP_NAME WEBAPP] DISABLE MATOMO
	sed -i 's|#ALLOW_MATOMO|#DISABLE_MATOMO|g' /etc/nginx/conf.d/default.conf
	echo [$KAPP_NAME WEBAPP] Clean MATOMO module injection
	#sed -i 's|...forRoot({trackerUrl:"[^"]*",siteId:"[^"]*"}),...forRoot({interceptors:[^}]*})|''|g' /usr/share/nginx/html/main*.js
fi



if [ "$ENABLE_TLS" = "true" ]; then
	echo [$KAPP_NAME WEBAPP] enable TLS "$ENABLE_TLS"
	ls -al /certs/
    sed -i 's|#TO_ENABLE_TLS||g' /etc/nginx/conf.d/default.conf
else
    echo [$KAPP_NAME WEBAPP] disable TLS "$ENABLE_TLS"
	sed -i 's|#TO_DISABLE_TLS||g' /etc/nginx/conf.d/default.conf
fi



if [ "$1" = "/bin/sh" ]; then
	echo [$KAPP_NAME WEBAPP] start $3 -g "daemon off;"
	exec /docker-entrypoint.sh $3 -g "daemon off;"
elif [ "$1" = "nginx-debug" ]; then
	echo [$KAPP_NAME WEBAPP] start $@ -g "daemon off;"
	exec /docker-entrypoint.sh $@ -g "daemon off;"
elif [ "$1" = "nginx" ]; then
	echo [$KAPP_NAME WEBAPP] start $@ -g "daemon off;"
	exec /docker-entrypoint.sh $@ -g "daemon off;"
else
	echo [$KAPP_NAME WEBAPP] start $@
	exec /docker-entrypoint.sh $@
fi