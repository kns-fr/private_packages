#!bash 
file="/backups/mariadb_$(date +'%Y-%m-%d_%H-%M-%S').sql"
docker exec ksocle-mariadb bash -c "mariadb-dump --database kbase -C --user=kdep --password=KsocleP@ssw0rdK@EnEs69 > $file"
