-- Generic dataset

--Role
-- expected ID : 8
insert into knsobject (externalId, type, kNSAttributes) VALUES ('CN=USER_ADMIN,OU=ROLE,DC=KDEP', 'ROLE', '{"cn":"USER_ADMIN", "kNSString55":"KDIR","displayName":"Administrateur"}');

