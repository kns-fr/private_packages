# Deploiment par docker-compose
1. mettre à jour le fichier .env
2. créer si besoin le fichier initBdd.tar à partir des différents fichier sql (initialisation des permiers utilisateurs admin !)
3. Lancer le docker compose
```shell
docker-compose pull
docker-compose up --force-recreate -d
```

- la base de donnée (mariadb) est dans un volume docker
- le basckend est servi à travers le front


# Tips
build and run local
```shell
docker build -f ./deployment/docker/kdir-webapp/Dockerfile -t 5qcniilc.gra7.container-registry.ovh.net/kdir/kdir-front-ght-ad:latest .
docker pull 5qcniilc.gra7.container-registry.ovh.net/kdir/kdir-api-v2:latest
cd d .\deployment\compose\
docker-compose up --force-recreate -d
cd ../..
```